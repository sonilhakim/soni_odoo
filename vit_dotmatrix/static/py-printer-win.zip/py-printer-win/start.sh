set FLASK_APP=printer.py
flask run --port=8000
